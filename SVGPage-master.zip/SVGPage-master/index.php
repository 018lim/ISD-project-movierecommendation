<?php
header('location:Templates');
?>
