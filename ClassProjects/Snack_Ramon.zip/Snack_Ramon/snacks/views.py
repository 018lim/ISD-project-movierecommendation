from django.shortcuts import render, redirect

# Create your views here.
from django.shortcuts import render, redirect

from django.http import HttpResponse
from django.template import loader

from snacks.models import Snack
from snacks.forms import SnackForm


def list_snacks(request):
    name = "Snacks List"
    snacks = Snack.objects.all()
    temp = loader.get_template('list_snacks.html')
    context = {
        'name': name,
        'snacks': snacks,
    }
    return HttpResponse(temp.render(context, request))


def create_snack(request):
    form = SnackForm(request.POST or None)

    if form.is_valid():
        form.save()
        return redirect('list_snacks')

    return render(request, 'snack_form.html', {'form': form})


def update_snack(request, id):
    snack = Snack.objects.get(id=id)
    form = SnackForm(request.POST or None, instance=snack)

    if form.is_valid():
        form.save()
        return redirect('list_snacks')

    return render(request, 'snack_form.html', {'form': form, 'snack': snack})


def delete_snack(request, id):
    snack = Snack.objects.get(id=id)

    if request.method == 'POST':
        snack.delete()
        return redirect('list_snacks')

    return render(request, 'snack_delete_confirm.html', {'snack': snack})
